# EchoShield deployment

This repository is configured for a single-service Docker deployment on Render.

Build/runtime:
- React/Vite is compiled during the Docker build.
- FastAPI serves the compiled React app.
- `/detect` remains the API endpoint.
- FFmpeg is installed for Pydub/WebM decoding.
- PyTorch is installed as a CPU build.

Render:
- Create a Web Service from this GitHub repository.
- Runtime: Docker
- No separate frontend service is needed.
- The service will receive Render's `$PORT` automatically.

Important:
- The browser microphone requires HTTPS; Render's public service URL provides HTTPS.
- The first request after an idle period can be slow on a free instance because the service may sleep.
